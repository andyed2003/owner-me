package mySetImpl.org.soton.ac.uk;

import java.util.HashSet;

public class MySetImpl<E> extends HashSet<E> {

	private static final long serialVersionUID = -3571601761764405294L;

	public E get() {
		// TODO Auto-generated method stub
		return this.iterator().next();
	}

	



}
