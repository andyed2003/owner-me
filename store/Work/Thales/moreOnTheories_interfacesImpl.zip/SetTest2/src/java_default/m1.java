package java_default;

import mySetImpl.org.soton.ac.uk.MySetImpl;
// Task: m1

public class m1 implements Runnable
{
	
	// Instance variables and constants
	protected MySetImpl<Integer> setOfINT = new MySetImpl<Integer>();
	
	protected Integer INT_element;
	protected int priority = 5;
	
	public m1()
	{
		setOfINT.add(new Integer(3));
		setOfINT.add(new Integer(2));
		setOfINT.add(new Integer(1));
	}
	
	public void run()
	{
		INT_element = setOfINT.get();
		System.out.println("INT_element: " + INT_element);
	}
	
	// Subroutines
	public int getPriority()
	{
		return priority;
	}
	
}
