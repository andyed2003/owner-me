// MainEntry: MainEntry
package java_default;
import java.util.HashMap;
public class MainEntry
{
	protected static final int FAILURES_TOLARABLE = 4;
	
	
	protected static final int FAN_SPEED_FAULT = 1000;
	
	protected static final int HWM_AMBIENT = 90000;
	
	
	protected static final int fanSpeed_get = 2;
	
	
	protected static final int HWM_PSU = 36000;
	
	protected static final int tempAmbient_get = 1;
	
	
	
	
	protected static final int LWM_AMBIENT = 45000;
	
	public enum fanCtrlState_STATES
	{
		Step,
		Control,
		Normal,
		SpeedCheck,
		FailureCount,
		Broken,
		BrokenSpeedCheck,
	}
	
	
	protected static final int LWM_PSU = 32000;
	
	protected static final int FAN_SPEED_OFF = 0;
	
	protected static final int tempPSU_get = 0;
	
	//	Stores all tasks and shared machines with their names
	private static HashMap<String, Object> tasks = new HashMap<String, Object>();
	
	public static void addTask(Object task, String name)
	{
		tasks.put(name, task);
	}
	
	public static Object getTask(String name)
	{
		return tasks.get(name);
	}
	
	public static void main(String [] args)
	{
		// Create the tasks
		FanCtrlMachine task0 = new FanCtrlMachine();
		
		// Store the tasks in a shared map to allow communication between tasks
		addTask(task0, "FanCtrlMachine");
		
		// Create the threads
		Thread thread0 = new Thread(task0);
		
		// Set priority
		thread0.setPriority(task0.getPriority());
		
		// Start the threads
		thread0.start();
	}
}
