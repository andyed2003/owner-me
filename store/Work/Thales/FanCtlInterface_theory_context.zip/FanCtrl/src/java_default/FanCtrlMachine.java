package java_default;
import static java_default.MainEntry.fanCtrlState_STATES.Broken;
import static java_default.MainEntry.fanCtrlState_STATES.*;
import myPkg.Custom;
import java_default.MainEntry.fanCtrlState_STATES;
import static java_default.MainEntry.*;
// Task: FanCtrlMachine

public class FanCtrlMachine implements Runnable
{
	
	// Instance variables and constants
	protected fanCtrlState_STATES fanCtrlState = Step;
	protected int failureCount = 0;
	protected int tempPSU = (LWM_PSU + 100);
	protected int tempAmbient = (HWM_AMBIENT + 100);
	protected int fanSpeed = (FAN_SPEED_FAULT + 10);
	protected boolean fanOn = true;
	protected int priority = 5;
	
	public FanCtrlMachine()
	{
	}
	
	public void run()
	{
		while(true)
		{
			// [Internal] Timer information for repeating or periodic tasks
			long THREAD_START_TIME = System.currentTimeMillis();
			
			// Translated code
			((FanCtrlMachine)MainEntry.getTask("FanCtrlMachine")).fanCtrlStatestateMachine();
			System.out.println("----------- fanCtrlState: " + fanCtrlState);
			System.out.println("failureCount: " + failureCount);
			
			// [Internal] Code to monitor time between periodic tasks
			long THREAD_END_TIME = System.currentTimeMillis();
			long THREAD_TIME_TAKEN = THREAD_END_TIME - THREAD_START_TIME;
			try
			{
				Thread.sleep(Math.max(1000 - THREAD_TIME_TAKEN,0));
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}
	}
	
	// Subroutines
	public void fanCtrlStatestateMachine()
	{
		// Translated code
		switch(fanCtrlState)
		{
			case Step:
			tempPSU = Custom.get(tempPSU_get);
			tempAmbient = Custom.get(tempAmbient_get);
			fanCtrlState = Control;
			break;
			case Control:
			if ((!((tempPSU <= LWM_PSU) && (tempAmbient <= LWM_AMBIENT))) && (!((tempPSU >= HWM_PSU) || (tempAmbient >= HWM_AMBIENT))))
			{
				fanCtrlState = Normal;
			}
			else if (((tempPSU >= HWM_PSU) || (tempAmbient >= HWM_AMBIENT)))
			{
				fanOn = true;
				fanCtrlState = Normal;
			}
			else if (((tempPSU <= LWM_PSU) && (tempAmbient <= LWM_AMBIENT)))
			{
				fanCtrlState = Normal;
				fanOn = false;
			}
			break;
			case Normal:
			fanSpeed = Custom.get(fanSpeed_get);
			fanCtrlState = SpeedCheck;
			break;
			case SpeedCheck:
			if (((fanOn == false) || (fanSpeed >= FAN_SPEED_FAULT)) && ((fanOn == true) || (fanSpeed <= FAN_SPEED_OFF)))
			{
				failureCount = 0;
				fanCtrlState = Step;
			}
			else if (((fanOn == false) || (fanSpeed < FAN_SPEED_FAULT)) && ((fanOn == true) || (fanSpeed > FAN_SPEED_OFF)) && (failureCount <= FAILURES_TOLARABLE))
			{
				failureCount = (failureCount + 1);
				fanCtrlState = FailureCount;
			}
			break;
			case FailureCount:
			if (((failureCount > 0) && (failureCount <= FAILURES_TOLARABLE)))
			{
				fanCtrlState = Step;
			}
			else if ((failureCount > FAILURES_TOLARABLE))
			{
				fanCtrlState = Broken;
			}
			break;
			case Broken:
			fanCtrlState = BrokenSpeedCheck;
			fanSpeed = Custom.get(fanSpeed_get);
			break;
			case BrokenSpeedCheck:
			if (((fanOn == true) || (fanSpeed > FAN_SPEED_OFF)) && ((fanOn == false) || (fanSpeed < FAN_SPEED_FAULT)))
			{
				fanCtrlState = Broken;
			}
			else if (((fanOn == true) || (fanSpeed <= FAN_SPEED_OFF)) && ((fanOn == false) || (fanSpeed >= FAN_SPEED_FAULT)))
			{
				fanCtrlState = Step;
				failureCount = 0;
			}
			break;
		}
	}
	
	public int getPriority()
	{
		return priority;
	}
	
}
