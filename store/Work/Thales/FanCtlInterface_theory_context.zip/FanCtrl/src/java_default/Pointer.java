// Task: Pointer
package java_default;
// Used to act as a pointer for out parameters in call-subroutines
public class Pointer<T>
{
	T value;
}
